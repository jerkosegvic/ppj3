int main(void) {
    return "\a\b\c";
}

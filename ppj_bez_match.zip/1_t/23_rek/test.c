int main(void) {
    return main();
    x = 2;
}

int x = 3;
int main(void) {
    int x(int y), z = x;
    return 0;
}

int main(void) {
    return x;
}

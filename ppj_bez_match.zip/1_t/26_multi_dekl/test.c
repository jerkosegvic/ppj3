int main(void) {
    int x, y, z, f(int x);
    char a[3], b[4];
    x = y + z;
    z = a[2] + b[3];
    y = f(x);
    return f;
}
int f(int x) {
    return x;
}

int f(int a, int b, char c) {
    return a + b + c;
}
int main(void) {
    int x = f(1, 'a', 'a');
    return f(1, 'a', 'a', 2);
}

# 3. laboratorijska vježba iz PPJ-a

##### Jerko Šegvić i Mislav Đomlija

- za test izvrši naredbu `bash test.sh`
- za pokretanje analize generativnog stabla `python SemantickiAnalizator.py < input.txt`